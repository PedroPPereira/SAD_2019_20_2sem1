

void adc_init(void);
unsigned int readADC(unsigned char canal);
