

  #define _XTAL_FREQ 4000000

  void PWM1_Init(unsigned int);
  void PWM1_Start(void);
  void PWM1_Set_Duty(unsigned char);
