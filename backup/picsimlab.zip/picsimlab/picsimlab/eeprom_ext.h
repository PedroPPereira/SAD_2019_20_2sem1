#include <xc.h>


unsigned char e2pext_r(unsigned int addr);
void e2pext_w(unsigned int addr, unsigned char val);
