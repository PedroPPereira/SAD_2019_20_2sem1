

unsigned char display7s(unsigned char v);
unsigned char selDISP(unsigned int num);
